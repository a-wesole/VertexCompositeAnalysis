import FWCore.ParameterSet.Config as cms

genSuperChicParticles = cms.EDProducer('GenParticleSuperChicFixer',
  genPars = cms.InputTag('genParticles', '', 'SIM'),
  mightGet = cms.optional.untracked.vstring
)
