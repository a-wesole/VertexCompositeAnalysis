import FWCore.ParameterSet.Config as cms

dedxMuon = cms.EDProducer('DeDxMuonProducer',
  dedx = cms.InputTag('dedxHarmonic2'),
  muons = cms.InputTag('patMuonsWithoutTrigger'),
  mightGet = cms.optional.untracked.vstring
)
