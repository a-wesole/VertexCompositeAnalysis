import FWCore.ParameterSet.Config as cms

genParticles = cms.EDProducer('GenParticleFixer',
  genPars = cms.InputTag('genParticles', '', 'SIM'),
  momPdgId = cms.int32(0),
  dauPdgId = cms.int32(13),
  mightGet = cms.optional.untracked.vstring
)
