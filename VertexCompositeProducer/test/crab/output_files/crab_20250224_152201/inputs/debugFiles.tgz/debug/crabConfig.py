from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = ''
config.General.transferOutputs = True
config.General.workArea = 'output_files'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.JobType.psetName = '/home/awesole/VertexCP_clean/CMSSW_13_2_11/src/VertexCompositeAnalysis/VertexCompositeProducer/test/run_VCProducer.py'
config.section_('Data')
config.Data.lumiMask = 'mini.json'
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.splitting = 'LumiBased'
config.Data.inputDataset = '/HIPhysicsRawPrime0/HIRun2023A-PromptReco-v2/MINIAOD'
config.Data.outputDatasetTag = 'D0Test'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/awesolek/D0Test'
config.section_('Site')
config.Site.storageSite = 'T2_US_Purdue'
config.section_('User')
config.section_('Debug')
